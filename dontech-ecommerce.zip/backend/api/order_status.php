<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/jwt.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed', 405);
}

$payload = require_auth();
$userId = (int)$payload['sub'];
$orderId = (int)($_GET['order_id'] ?? 0);

if (!$orderId) {
    json_error('order_id is required', 422);
}

$pdo = get_pdo();
$stmt = $pdo->prepare('
    SELECT o.id, o.order_number, o.status, o.total, o.payment_method,
           p.status AS payment_status, p.mpesa_receipt_number
    FROM orders o
    LEFT JOIN payments p ON p.order_id = o.id
    WHERE o.id = ? AND o.user_id = ?
    ORDER BY p.id DESC LIMIT 1
');
$stmt->execute([$orderId, $userId]);
$order = $stmt->fetch();

if (!$order) {
    json_error('Order not found', 404);
}

json_response(['order' => $order]);
