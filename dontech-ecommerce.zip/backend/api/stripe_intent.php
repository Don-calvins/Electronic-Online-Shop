<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/jwt.php';
require_once __DIR__ . '/../includes/stripe.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed', 405);
}

$payload = require_auth();
$userId = (int)$payload['sub'];

$data = json_input();
require_fields($data, ['order_id']);
$orderId = (int)$data['order_id'];

$pdo = get_pdo();
$stmt = $pdo->prepare('SELECT id, order_number, total FROM orders WHERE id = ? AND user_id = ?');
$stmt->execute([$orderId, $userId]);
$order = $stmt->fetch();

if (!$order) {
    json_error('Order not found', 404);
}

try {
    $stripe = new StripeClient();
    $intent = $stripe->createPaymentIntent(
        (float)$order['total'],
        'usd',
        ['order_id' => $orderId, 'order_number' => $order['order_number']]
    );

    $stmt = $pdo->prepare('
        UPDATE payments
        SET status = "pending", stripe_payment_intent_id = ?, stripe_client_secret = ?, raw_response = ?
        WHERE order_id = ? AND method = "card"
        ORDER BY id DESC LIMIT 1
    ');
    $stmt->execute([$intent['id'] ?? null, $intent['client_secret'] ?? null, json_encode($intent), $orderId]);

    json_response([
        'client_secret' => $intent['client_secret'] ?? null,
        'publishable_key' => STRIPE_PUBLISHABLE_KEY,
    ]);
} catch (Throwable $e) {
    // Common cause during development: placeholder key in config/stripe.php
    json_error('Stripe request failed: ' . $e->getMessage(), 502);
}
