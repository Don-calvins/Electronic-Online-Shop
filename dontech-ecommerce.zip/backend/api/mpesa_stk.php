<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/jwt.php';
require_once __DIR__ . '/../includes/mpesa.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed', 405);
}

$payload = require_auth();
$userId = (int)$payload['sub'];

$data = json_input();
require_fields($data, ['order_id', 'phone']);

$orderId = (int)$data['order_id'];
$phone = MpesaClient::normalizePhone($data['phone']);

if (!preg_match('/^254(7|1)\d{8}$/', $phone)) {
    json_error('Enter a valid Kenyan phone number, e.g. 0712345678', 422);
}

$pdo = get_pdo();

$stmt = $pdo->prepare('SELECT id, order_number, total, user_id FROM orders WHERE id = ? AND user_id = ?');
$stmt->execute([$orderId, $userId]);
$order = $stmt->fetch();

if (!$order) {
    json_error('Order not found', 404);
}

try {
    $mpesa = new MpesaClient();
    $result = $mpesa->stkPush(
        $phone,
        (float)$order['total'],
        $order['order_number'],
        'Don-Tech order ' . $order['order_number']
    );

    $stmt = $pdo->prepare('
        UPDATE payments
        SET status = "pending",
            mpesa_checkout_request_id = ?,
            mpesa_merchant_request_id = ?,
            mpesa_phone = ?,
            raw_response = ?
        WHERE order_id = ? AND method = "mpesa"
        ORDER BY id DESC LIMIT 1
    ');
    $stmt->execute([
        $result['CheckoutRequestID'] ?? null,
        $result['MerchantRequestID'] ?? null,
        $phone,
        json_encode($result),
        $orderId,
    ]);

    json_response([
        'message' => 'STK push sent. Check your phone to complete payment.',
        'checkout_request_id' => $result['CheckoutRequestID'] ?? null,
    ]);
} catch (Throwable $e) {
    // Common cause during development: placeholder credentials in includes/mpesa.php
    json_error('M-Pesa request failed: ' . $e->getMessage(), 502);
}
