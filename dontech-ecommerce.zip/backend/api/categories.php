<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed', 405);
}

$pdo = get_pdo();
$categories = $pdo->query('SELECT id, name, slug FROM categories ORDER BY name')->fetchAll();

json_response(['categories' => $categories]);
