<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/jwt.php';

require_admin();
$pdo = get_pdo();
$method = $_SERVER['REQUEST_METHOD'];

function slugify(string $text): string {
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/', '-', $text);
    return trim($text, '-');
}

if ($method === 'GET') {
    // Admin sees all products regardless of status
    $stmt = $pdo->query('
        SELECT p.*, c.name AS category_name
        FROM products p JOIN categories c ON c.id = p.category_id
        ORDER BY p.created_at DESC
    ');
    json_response(['products' => $stmt->fetchAll()]);
}

if ($method === 'POST') {
    $data = json_input();
    require_fields($data, ['name', 'category_id', 'price', 'stock']);

    $slug = slugify($data['name']) . '-' . substr(uniqid(), -5);

    $stmt = $pdo->prepare('
        INSERT INTO products (category_id, name, slug, description, price, compare_at_price,
                               stock, image_url, is_featured, is_new, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ');
    $stmt->execute([
        (int)$data['category_id'],
        $data['name'],
        $slug,
        $data['description'] ?? null,
        (float)$data['price'],
        isset($data['compare_at_price']) && $data['compare_at_price'] !== '' ? (float)$data['compare_at_price'] : null,
        (int)$data['stock'],
        $data['image_url'] ?? null,
        !empty($data['is_featured']) ? 1 : 0,
        !empty($data['is_new']) ? 1 : 0,
        $data['status'] ?? 'active',
    ]);

    json_response(['id' => (int)$pdo->lastInsertId(), 'slug' => $slug], 201);
}

if ($method === 'PUT') {
    $data = json_input();
    require_fields($data, ['id']);
    $id = (int)$data['id'];

    $fields = [];
    $params = [];
    foreach (['category_id', 'name', 'description', 'price', 'compare_at_price', 'stock', 'image_url', 'is_featured', 'is_new', 'status'] as $f) {
        if (array_key_exists($f, $data)) {
            $fields[] = "$f = ?";
            $params[] = $data[$f];
        }
    }
    if (!$fields) {
        json_error('No fields to update', 422);
    }
    $params[] = $id;

    $stmt = $pdo->prepare('UPDATE products SET ' . implode(', ', $fields) . ' WHERE id = ?');
    $stmt->execute($params);

    json_response(['message' => 'Product updated']);
}

if ($method === 'DELETE') {
    $id = (int)($_GET['id'] ?? 0);
    if (!$id) json_error('id is required', 422);

    $pdo->prepare('UPDATE products SET status = "archived" WHERE id = ?')->execute([$id]);
    json_response(['message' => 'Product archived']);
}

json_error('Method not allowed', 405);
