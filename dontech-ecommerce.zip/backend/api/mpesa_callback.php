<?php
/**
 * M-Pesa calls this URL directly (server-to-server) after the customer
 * completes or cancels the STK push prompt. This URL must be PUBLICLY
 * reachable over HTTPS for Safaricom to reach it — localhost won't work
 * unless tunneled (e.g. with ngrok) during development.
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json');

$raw = file_get_contents('php://input');
$payload = json_decode($raw, true);

// Always log the raw callback for debugging, regardless of how parsing goes
file_put_contents(__DIR__ . '/../mpesa_callback_log.txt', date('c') . " " . $raw . "\n", FILE_APPEND);

$callback = $payload['Body']['stkCallback'] ?? null;
if (!$callback) {
    http_response_code(200); // Acknowledge anyway so Safaricom doesn't retry forever
    echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Accepted']);
    exit;
}

$checkoutRequestId = $callback['CheckoutRequestID'] ?? null;
$resultCode = $callback['ResultCode'] ?? 1;

$pdo = get_pdo();

$stmt = $pdo->prepare('SELECT id, order_id FROM payments WHERE mpesa_checkout_request_id = ?');
$stmt->execute([$checkoutRequestId]);
$payment = $stmt->fetch();

if ($payment) {
    if ($resultCode === 0) {
        // Success - extract the M-Pesa receipt number from CallbackMetadata
        $receiptNumber = null;
        foreach (($callback['CallbackMetadata']['Item'] ?? []) as $item) {
            if (($item['Name'] ?? '') === 'MpesaReceiptNumber') {
                $receiptNumber = $item['Value'];
            }
        }

        $pdo->prepare('
            UPDATE payments SET status = "success", mpesa_receipt_number = ?, raw_response = ?
            WHERE id = ?
        ')->execute([$receiptNumber, $raw, $payment['id']]);

        $pdo->prepare('UPDATE orders SET status = "paid" WHERE id = ?')->execute([$payment['order_id']]);
    } else {
        $pdo->prepare('UPDATE payments SET status = "failed", raw_response = ? WHERE id = ?')
            ->execute([$raw, $payment['id']]);

        $pdo->prepare('UPDATE orders SET status = "failed" WHERE id = ?')->execute([$payment['order_id']]);
    }
}

// Always respond 200 with this exact shape, or Safaricom will retry the callback
echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Accepted']);
