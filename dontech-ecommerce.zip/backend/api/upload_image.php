<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/jwt.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed', 405);
}

if (empty($_FILES['image'])) {
    json_error('No image uploaded (expected multipart field "image")', 422);
}

$file = $_FILES['image'];

if ($file['error'] !== UPLOAD_ERR_OK) {
    json_error('Upload failed (error code ' . $file['error'] . ')', 422);
}

$allowedTypes = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

if (!isset($allowedTypes[$mime])) {
    json_error('Only JPEG, PNG, and WebP images are allowed', 422);
}

if ($file['size'] > 5 * 1024 * 1024) {
    json_error('Image must be under 5MB', 422);
}

if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

$filename = bin2hex(random_bytes(16)) . '.' . $allowedTypes[$mime];
$destination = UPLOAD_DIR . $filename;

if (!move_uploaded_file($file['tmp_name'], $destination)) {
    json_error('Could not save uploaded file', 500);
}

json_response(['url' => UPLOAD_URL . $filename], 201);
