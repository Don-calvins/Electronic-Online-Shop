<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/jwt.php';

$payload = require_auth();
$userId = (int)$payload['sub'];
$pdo = get_pdo();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $pdo->prepare("
        SELECT w.id AS wishlist_item_id, p.id AS product_id, p.name, p.slug,
               p.price, p.image_url, p.rating
        FROM wishlist_items w
        JOIN products p ON p.id = w.product_id
        WHERE w.user_id = ?
        ORDER BY w.created_at DESC
    ");
    $stmt->execute([$userId]);
    json_response(['items' => $stmt->fetchAll()]);
}

if ($method === 'POST') {
    $data = json_input();
    require_fields($data, ['product_id']);
    $productId = (int)$data['product_id'];

    $stmt = $pdo->prepare('SELECT id FROM products WHERE id = ?');
    $stmt->execute([$productId]);
    if (!$stmt->fetch()) {
        json_error('Product not found', 404);
    }

    $stmt = $pdo->prepare('
        INSERT IGNORE INTO wishlist_items (user_id, product_id) VALUES (?, ?)
    ');
    $stmt->execute([$userId, $productId]);

    json_response(['message' => 'Added to wishlist'], 201);
}

if ($method === 'DELETE') {
    $productId = (int)($_GET['product_id'] ?? 0);
    if (!$productId) json_error('product_id is required', 422);

    $stmt = $pdo->prepare('DELETE FROM wishlist_items WHERE user_id = ? AND product_id = ?');
    $stmt->execute([$userId, $productId]);

    json_response(['message' => 'Removed from wishlist']);
}

json_error('Method not allowed', 405);
