<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/jwt.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed', 405);
}

$data = json_input();
require_fields($data, ['name', 'email', 'password']);

$name = trim($data['name']);
$email = strtolower(trim($data['email']));
$password = $data['password'];
$phone = trim($data['phone'] ?? '');

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_error('Invalid email address', 422);
}
if (strlen($password) < 8) {
    json_error('Password must be at least 8 characters', 422);
}

$pdo = get_pdo();

$stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
$stmt->execute([$email]);
if ($stmt->fetch()) {
    json_error('An account with this email already exists', 409);
}

$hash = password_hash($password, PASSWORD_BCRYPT);

$stmt = $pdo->prepare('INSERT INTO users (name, email, password_hash, phone, role) VALUES (?, ?, ?, ?, ?)');
$stmt->execute([$name, $email, $hash, $phone ?: null, 'customer']);
$userId = (int)$pdo->lastInsertId();

$token = jwt_encode(['sub' => $userId, 'email' => $email, 'role' => 'customer', 'name' => $name]);

json_response([
    'token' => $token,
    'user' => ['id' => $userId, 'name' => $name, 'email' => $email, 'role' => 'customer'],
], 201);
