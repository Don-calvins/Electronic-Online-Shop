<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/jwt.php';

require_admin();
$pdo = get_pdo();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $pdo->query('
        SELECT o.id, o.order_number, o.status, o.total, o.payment_method,
               o.shipping_name, o.shipping_phone, o.created_at, u.email AS customer_email
        FROM orders o
        JOIN users u ON u.id = o.user_id
        ORDER BY o.created_at DESC
    ');
    json_response(['orders' => $stmt->fetchAll()]);
}

if ($method === 'PUT') {
    $data = json_input();
    require_fields($data, ['id', 'status']);

    $validStatuses = ['pending','paid','processing','shipped','completed','cancelled','failed'];
    if (!in_array($data['status'], $validStatuses, true)) {
        json_error('Invalid status', 422);
    }

    $stmt = $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?');
    $stmt->execute([$data['status'], (int)$data['id']]);

    json_response(['message' => 'Order status updated']);
}

json_error('Method not allowed', 405);
