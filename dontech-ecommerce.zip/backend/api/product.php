<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed', 405);
}

$identifier = $_GET['slug'] ?? $_GET['id'] ?? null;
if (!$identifier) {
    json_error('Provide a slug or id', 422);
}

$pdo = get_pdo();

$isNumeric = ctype_digit((string)$identifier);
$stmt = $pdo->prepare("
    SELECT p.*, c.name AS category_name, c.slug AS category_slug
    FROM products p
    JOIN categories c ON c.id = p.category_id
    WHERE " . ($isNumeric ? 'p.id = ?' : 'p.slug = ?') . "
    LIMIT 1
");
$stmt->execute([$identifier]);
$product = $stmt->fetch();

if (!$product) {
    json_error('Product not found', 404);
}

json_response(['product' => $product]);
