<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/jwt.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed', 405);
}

$payload = require_auth();
$userId = (int)$payload['sub'];

$data = json_input();
require_fields($data, ['payment_method', 'shipping_name', 'shipping_phone', 'shipping_address', 'shipping_city']);

$paymentMethod = $data['payment_method']; // 'mpesa' | 'card'
if (!in_array($paymentMethod, ['mpesa', 'card'], true)) {
    json_error('payment_method must be "mpesa" or "card"', 422);
}

$pdo = get_pdo();

// Load cart
$stmt = $pdo->prepare("
    SELECT ci.product_id, ci.quantity, p.name, p.price, p.stock
    FROM cart_items ci
    JOIN products p ON p.id = ci.product_id
    WHERE ci.user_id = ?
");
$stmt->execute([$userId]);
$cartItems = $stmt->fetchAll();

if (!$cartItems) {
    json_error('Your cart is empty', 422);
}

// Validate stock
foreach ($cartItems as $item) {
    if ($item['quantity'] > $item['stock']) {
        json_error("Not enough stock for {$item['name']}", 422);
    }
}

$subtotal = 0;
foreach ($cartItems as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}
$shippingFee = $subtotal >= 99 ? 0 : 9.99; // matches "free shipping over $99" on the storefront
$total = round($subtotal + $shippingFee, 2);

try {
    $pdo->beginTransaction();

    $orderNumber = generate_order_number();
    $stmt = $pdo->prepare('
        INSERT INTO orders (user_id, order_number, status, subtotal, shipping_fee, total,
                             payment_method, shipping_name, shipping_phone, shipping_address,
                             shipping_city, notes)
        VALUES (?, ?, "pending", ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ');
    $stmt->execute([
        $userId, $orderNumber, $subtotal, $shippingFee, $total,
        $paymentMethod, $data['shipping_name'], $data['shipping_phone'],
        $data['shipping_address'], $data['shipping_city'], $data['notes'] ?? null,
    ]);
    $orderId = (int)$pdo->lastInsertId();

    $itemStmt = $pdo->prepare('
        INSERT INTO order_items (order_id, product_id, product_name, unit_price, quantity, line_total)
        VALUES (?, ?, ?, ?, ?, ?)
    ');
    $stockStmt = $pdo->prepare('UPDATE products SET stock = stock - ? WHERE id = ?');

    foreach ($cartItems as $item) {
        $lineTotal = round($item['price'] * $item['quantity'], 2);
        $itemStmt->execute([$orderId, $item['product_id'], $item['name'], $item['price'], $item['quantity'], $lineTotal]);
        $stockStmt->execute([$item['quantity'], $item['product_id']]);
    }

    // Create a payment record. Actual gateway calls happen in mpesa_stk.php / stripe_intent.php,
    // called separately by the frontend right after this returns.
    $payStmt = $pdo->prepare('
        INSERT INTO payments (order_id, method, amount, status)
        VALUES (?, ?, ?, "initiated")
    ');
    $payStmt->execute([$orderId, $paymentMethod, $total]);
    $paymentId = (int)$pdo->lastInsertId();

    // Clear the cart now that it's been converted into an order
    $pdo->prepare('DELETE FROM cart_items WHERE user_id = ?')->execute([$userId]);

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    json_error('Could not create order: ' . $e->getMessage(), 500);
}

json_response([
    'order' => [
        'id' => $orderId,
        'order_number' => $orderNumber,
        'subtotal' => $subtotal,
        'shipping_fee' => $shippingFee,
        'total' => $total,
        'payment_method' => $paymentMethod,
        'status' => 'pending',
    ],
    'payment_id' => $paymentId,
], 201);
