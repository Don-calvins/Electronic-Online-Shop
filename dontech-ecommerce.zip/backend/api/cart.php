<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/jwt.php';

$payload = require_auth();
$userId = (int)$payload['sub'];
$pdo = get_pdo();

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $pdo->prepare("
        SELECT ci.id AS cart_item_id, ci.quantity, ci.product_id,
               p.name, p.slug, p.price, p.image_url, p.stock
        FROM cart_items ci
        JOIN products p ON p.id = ci.product_id
        WHERE ci.user_id = ?
        ORDER BY ci.created_at DESC
    ");
    $stmt->execute([$userId]);
    $items = $stmt->fetchAll();

    $subtotal = 0;
    foreach ($items as $item) {
        $subtotal += $item['price'] * $item['quantity'];
    }

    json_response([
        'items' => $items,
        'item_count' => array_sum(array_column($items, 'quantity')),
        'subtotal' => round($subtotal, 2),
    ]);
}

if ($method === 'POST') {
    // Add to cart, or update quantity if it already exists
    $data = json_input();
    require_fields($data, ['product_id', 'quantity']);

    $productId = (int)$data['product_id'];
    $quantity = (int)$data['quantity'];

    if ($quantity < 1) {
        json_error('Quantity must be at least 1', 422);
    }

    $stmt = $pdo->prepare('SELECT id, stock FROM products WHERE id = ? AND status = "active"');
    $stmt->execute([$productId]);
    $product = $stmt->fetch();
    if (!$product) {
        json_error('Product not found', 404);
    }
    if ($quantity > $product['stock']) {
        json_error('Not enough stock available', 422);
    }

    $stmt = $pdo->prepare('
        INSERT INTO cart_items (user_id, product_id, quantity)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE quantity = VALUES(quantity), updated_at = NOW()
    ');
    $stmt->execute([$userId, $productId, $quantity]);

    json_response(['message' => 'Cart updated'], 200);
}

if ($method === 'DELETE') {
    $productId = (int)($_GET['product_id'] ?? 0);
    if (!$productId) {
        json_error('product_id is required', 422);
    }

    $stmt = $pdo->prepare('DELETE FROM cart_items WHERE user_id = ? AND product_id = ?');
    $stmt->execute([$userId, $productId]);

    json_response(['message' => 'Item removed']);
}

json_error('Method not allowed', 405);
