<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/jwt.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed', 405);
}

$payload = require_auth();
$userId = (int)$payload['sub'];
$pdo = get_pdo();

$orderId = $_GET['id'] ?? null;

if ($orderId) {
    // Single order with line items
    $stmt = $pdo->prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?');
    $stmt->execute([(int)$orderId, $userId]);
    $order = $stmt->fetch();

    if (!$order) {
        json_error('Order not found', 404);
    }

    $stmt = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ?');
    $stmt->execute([$order['id']]);
    $order['items'] = $stmt->fetchAll();

    json_response(['order' => $order]);
}

// List all orders for this user
$stmt = $pdo->prepare('
    SELECT id, order_number, status, total, payment_method, created_at
    FROM orders
    WHERE user_id = ?
    ORDER BY created_at DESC
');
$stmt->execute([$userId]);
json_response(['orders' => $stmt->fetchAll()]);
