<?php
require_once __DIR__ . '/../includes/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_error('Method not allowed', 405);
}

$pdo = get_pdo();

$category = $_GET['category'] ?? null;   // slug, e.g. "laptops"
$search = trim($_GET['q'] ?? '');
$featured = isset($_GET['featured']) ? (bool)$_GET['featured'] : null;
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = min(50, max(1, (int)($_GET['per_page'] ?? 12)));
$offset = ($page - 1) * $perPage;

$where = ["p.status = 'active'"];
$params = [];

if ($category && $category !== 'all') {
    $where[] = 'c.slug = ?';
    $params[] = $category;
}

if ($search !== '') {
    $where[] = '(p.name LIKE ? OR p.description LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($featured === true) {
    $where[] = 'p.is_featured = 1';
}

$whereSql = implode(' AND ', $where);

// total count for pagination
$countStmt = $pdo->prepare("
    SELECT COUNT(*) FROM products p
    JOIN categories c ON c.id = p.category_id
    WHERE $whereSql
");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();

$stmt = $pdo->prepare("
    SELECT p.id, p.name, p.slug, p.description, p.price, p.compare_at_price,
           p.stock, p.image_url, p.rating, p.is_featured, p.is_new,
           c.name AS category_name, c.slug AS category_slug
    FROM products p
    JOIN categories c ON c.id = p.category_id
    WHERE $whereSql
    ORDER BY p.created_at DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$products = $stmt->fetchAll();

json_response([
    'products' => $products,
    'pagination' => [
        'page' => $page,
        'per_page' => $perPage,
        'total' => $total,
        'total_pages' => (int)ceil($total / $perPage),
    ],
]);
