<?php
/**
 * Stripe webhook receiver. Configure this URL in your Stripe Dashboard
 * (Developers > Webhooks), listening for payment_intent.succeeded and
 * payment_intent.payment_failed. Must be a publicly reachable HTTPS URL
 * (use the Stripe CLI's `stripe listen --forward-to` for local testing).
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/stripe.php';
require_once __DIR__ . '/../includes/stripe.php';

header('Content-Type: application/json');

$rawPayload = file_get_contents('php://input');
$sigHeader = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

$event = StripeClient::verifyWebhookSignature($rawPayload, $sigHeader, STRIPE_WEBHOOK_SECRET);

if (!$event) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid signature']);
    exit;
}

$pdo = get_pdo();
$type = $event['type'] ?? '';
$intent = $event['data']['object'] ?? [];
$intentId = $intent['id'] ?? null;

if ($intentId) {
    $stmt = $pdo->prepare('SELECT id, order_id FROM payments WHERE stripe_payment_intent_id = ?');
    $stmt->execute([$intentId]);
    $payment = $stmt->fetch();

    if ($payment) {
        if ($type === 'payment_intent.succeeded') {
            $pdo->prepare('UPDATE payments SET status = "success", raw_response = ? WHERE id = ?')
                ->execute([json_encode($event), $payment['id']]);
            $pdo->prepare('UPDATE orders SET status = "paid" WHERE id = ?')->execute([$payment['order_id']]);
        } elseif ($type === 'payment_intent.payment_failed') {
            $pdo->prepare('UPDATE payments SET status = "failed", raw_response = ? WHERE id = ?')
                ->execute([json_encode($event), $payment['id']]);
            $pdo->prepare('UPDATE orders SET status = "failed" WHERE id = ?')->execute([$payment['order_id']]);
        }
    }
}

http_response_code(200);
echo json_encode(['received' => true]);
