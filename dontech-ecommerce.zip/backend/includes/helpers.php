<?php
/** Reads and JSON-decodes the request body. Returns [] if empty/invalid. */
function json_input(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function json_response($data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data);
    exit;
}

function json_error(string $message, int $status = 400): void {
    json_response(['error' => $message], $status);
}

/** Ensures required keys exist and are non-empty strings/values in $data. */
function require_fields(array $data, array $fields): void {
    $missing = [];
    foreach ($fields as $f) {
        if (!isset($data[$f]) || $data[$f] === '' || $data[$f] === null) {
            $missing[] = $f;
        }
    }
    if ($missing) {
        json_error('Missing required field(s): ' . implode(', ', $missing), 422);
    }
}

function generate_order_number(): string {
    return 'DT-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
}
