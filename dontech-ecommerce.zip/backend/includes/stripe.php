<?php
/**
 * Minimal Stripe API client using raw cURL calls against api.stripe.com.
 * Avoids requiring Composer/the stripe-php SDK so the project stays a
 * drop-in PHP folder. If you later add Composer, swap this for the
 * official stripe-php library — it's more robust.
 */

require_once __DIR__ . '/../config/stripe.php';

class StripeClient {
    private const BASE_URL = 'https://api.stripe.com/v1';

    private function request(string $method, string $path, array $params = []): array {
        $ch = curl_init(self::BASE_URL . $path);
        $opts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . STRIPE_SECRET_KEY],
        ];

        if ($method === 'POST') {
            $opts[CURLOPT_POST] = true;
            $opts[CURLOPT_POSTFIELDS] = http_build_query($params);
        }

        curl_setopt_array($ch, $opts);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true) ?? [];

        if ($httpCode >= 400) {
            $msg = $data['error']['message'] ?? "Stripe API error (HTTP $httpCode)";
            throw new RuntimeException($msg);
        }

        return $data;
    }

    /** Creates a PaymentIntent for the given amount (in the currency's smallest unit, e.g. cents). */
    public function createPaymentIntent(float $amountInDollars, string $currency, array $metadata = []): array {
        $params = [
            'amount' => (int)round($amountInDollars * 100),
            'currency' => $currency,
            'automatic_payment_methods[enabled]' => 'true',
        ];
        foreach ($metadata as $key => $value) {
            $params["metadata[$key]"] = $value;
        }
        return $this->request('POST', '/payment_intents', $params);
    }

    public function retrievePaymentIntent(string $id): array {
        return $this->request('GET', "/payment_intents/$id");
    }

    /**
     * Verifies a Stripe webhook signature without the SDK.
     * Returns the decoded event payload, or null if verification fails.
     */
    public static function verifyWebhookSignature(string $payload, string $sigHeader, string $secret): ?array {
        $parts = [];
        foreach (explode(',', $sigHeader) as $pair) {
            [$k, $v] = array_pad(explode('=', $pair, 2), 2, null);
            $parts[$k][] = $v;
        }

        $timestamp = $parts['t'][0] ?? null;
        $signatures = $parts['v1'] ?? [];

        if (!$timestamp || !$signatures) return null;

        $signedPayload = "$timestamp.$payload";
        $expectedSig = hash_hmac('sha256', $signedPayload, $secret);

        foreach ($signatures as $sig) {
            if (hash_equals($expectedSig, $sig)) {
                return json_decode($payload, true);
            }
        }

        return null;
    }
}
