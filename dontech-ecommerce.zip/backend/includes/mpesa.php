<?php
/**
 * M-Pesa Daraja API client (STK Push / Lipa Na M-Pesa Online).
 *
 * Fill in your credentials from https://developer.safaricom.co.ke
 * Sandbox values are pre-filled where Safaricom publishes fixed sandbox
 * defaults; everything else is a placeholder you MUST replace.
 */

define('MPESA_ENV', 'sandbox'); // 'sandbox' or 'production'
define('MPESA_CONSUMER_KEY', 'YOUR_CONSUMER_KEY_HERE');
define('MPESA_CONSUMER_SECRET', 'YOUR_CONSUMER_SECRET_HERE');
define('MPESA_SHORTCODE', '174379');           // Safaricom sandbox default till number
define('MPESA_PASSKEY', 'YOUR_LIPA_NA_MPESA_PASSKEY_HERE'); // from Daraja portal
define('MPESA_CALLBACK_URL', 'https://your-public-domain.example.com/backend/api/mpesa_callback.php');

class MpesaClient {
    private string $baseUrl;

    public function __construct() {
        $this->baseUrl = MPESA_ENV === 'production'
            ? 'https://api.safaricom.co.ke'
            : 'https://sandbox.safaricom.co.ke';
    }

    /** Get an OAuth access token. */
    public function getAccessToken(): string {
        $credentials = base64_encode(MPESA_CONSUMER_KEY . ':' . MPESA_CONSUMER_SECRET);

        $ch = curl_init("{$this->baseUrl}/oauth/v1/generate?grant_type=client_credentials");
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ["Authorization: Basic $credentials"],
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            throw new RuntimeException("M-Pesa auth failed (HTTP $httpCode): $response");
        }

        $data = json_decode($response, true);
        if (!isset($data['access_token'])) {
            throw new RuntimeException('M-Pesa auth response missing access_token: ' . $response);
        }

        return $data['access_token'];
    }

    /**
     * Initiates an STK Push prompt on the customer's phone.
     * @param string $phone Phone in format 2547XXXXXXXX (no +, no leading 0)
     * @param float  $amount
     * @param string $accountReference e.g. order number
     * @param string $description e.g. "Don-Tech order payment"
     */
    public function stkPush(string $phone, float $amount, string $accountReference, string $description): array {
        $token = $this->getAccessToken();
        $timestamp = date('YmdHis');
        $password = base64_encode(MPESA_SHORTCODE . MPESA_PASSKEY . $timestamp);

        $payload = [
            'BusinessShortCode' => MPESA_SHORTCODE,
            'Password' => $password,
            'Timestamp' => $timestamp,
            'TransactionType' => 'CustomerPayBillOnline',
            'Amount' => (int)ceil($amount), // M-Pesa sandbox requires whole numbers
            'PartyA' => $phone,
            'PartyB' => MPESA_SHORTCODE,
            'PhoneNumber' => $phone,
            'CallBackURL' => MPESA_CALLBACK_URL,
            'AccountReference' => $accountReference,
            'TransactionDesc' => $description,
        ];

        $ch = curl_init("{$this->baseUrl}/mpesa/stkpush/v1/processrequest");
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => [
                "Authorization: Bearer $token",
                'Content-Type: application/json',
            ],
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true) ?? [];

        if ($httpCode !== 200) {
            throw new RuntimeException("STK push failed (HTTP $httpCode): $response");
        }

        return $data; // contains MerchantRequestID, CheckoutRequestID, ResponseCode, etc.
    }

    /** Normalizes a Kenyan phone number to the 2547XXXXXXXX format M-Pesa expects. */
    public static function normalizePhone(string $phone): string {
        $phone = preg_replace('/\D/', '', $phone);
        if (str_starts_with($phone, '0')) {
            $phone = '254' . substr($phone, 1);
        } elseif (str_starts_with($phone, '7') || str_starts_with($phone, '1')) {
            $phone = '254' . $phone;
        }
        return $phone;
    }
}
