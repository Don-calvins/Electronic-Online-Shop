<?php
/**
 * Minimal HS256 JWT implementation — no Composer dependency required.
 * Good enough for a self-contained store; swap for firebase/php-jwt if you
 * later add Composer to the project.
 */

require_once __DIR__ . '/../config/database.php';

function jwt_base64url_encode(string $data): string {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function jwt_base64url_decode(string $data): string {
    return base64_decode(strtr($data, '-_', '+/'));
}

function jwt_encode(array $payload): string {
    $header = jwt_base64url_encode(json_encode(['typ' => 'JWT', 'alg' => 'HS256']));
    $payload['iat'] = time();
    $payload['exp'] = time() + (60 * 60 * 24 * 7); // 7 days
    $payloadEncoded = jwt_base64url_encode(json_encode($payload));
    $signature = hash_hmac('sha256', "$header.$payloadEncoded", JWT_SECRET, true);
    $signatureEncoded = jwt_base64url_encode($signature);
    return "$header.$payloadEncoded.$signatureEncoded";
}

/**
 * Returns the decoded payload array, or null if invalid/expired.
 */
function jwt_decode(string $token): ?array {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return null;
    [$header, $payload, $signature] = $parts;

    $expected = jwt_base64url_encode(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true));
    if (!hash_equals($expected, $signature)) return null;

    $data = json_decode(jwt_base64url_decode($payload), true);
    if (!is_array($data)) return null;
    if (isset($data['exp']) && $data['exp'] < time()) return null;

    return $data;
}

/**
 * Reads the Authorization: Bearer <token> header, validates it, and
 * returns the decoded payload. Sends a 401 and exits if invalid/missing.
 */
function require_auth(): array {
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authHeader = $headers['Authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';

    if (!preg_match('/Bearer\s+(\S+)/', $authHeader, $m)) {
        http_response_code(401);
        echo json_encode(['error' => 'Missing or malformed Authorization header']);
        exit;
    }

    $payload = jwt_decode($m[1]);
    if (!$payload) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid or expired token']);
        exit;
    }

    return $payload;
}

/** Like require_auth() but also requires role = admin. */
function require_admin(): array {
    $payload = require_auth();
    if (($payload['role'] ?? '') !== 'admin') {
        http_response_code(403);
        echo json_encode(['error' => 'Admin access required']);
        exit;
    }
    return $payload;
}

/** Optional auth — returns payload if a valid token is present, else null. Does not exit. */
function optional_auth(): ?array {
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authHeader = $headers['Authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/Bearer\s+(\S+)/', $authHeader, $m)) return null;
    return jwt_decode($m[1]);
}
