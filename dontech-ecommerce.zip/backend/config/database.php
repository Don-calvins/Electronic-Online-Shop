<?php
/**
 * Database configuration.
 * Update these to match your local MySQL setup (XAMPP/Laravel Herd/etc).
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'dontech');
define('DB_USER', 'root');
define('DB_PASS', '');       // set your MySQL root password here if you have one
define('DB_CHARSET', 'utf8mb4');

// Secret used to sign auth tokens. CHANGE THIS to a long random string before deploying.
define('JWT_SECRET', 'change-this-to-a-long-random-secret-before-production');

// Where uploaded product images are stored, relative to /backend
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_URL', '/backend/uploads/');

function get_pdo(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}
