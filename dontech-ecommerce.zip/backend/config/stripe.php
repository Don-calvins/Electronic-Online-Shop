<?php
/**
 * Stripe API keys. Get these from https://dashboard.stripe.com/apikeys
 * Use the *test* keys while developing.
 */
define('STRIPE_SECRET_KEY', 'sk_test_YOUR_STRIPE_SECRET_KEY_HERE');
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_YOUR_STRIPE_PUBLISHABLE_KEY_HERE');
define('STRIPE_WEBHOOK_SECRET', 'whsec_YOUR_WEBHOOK_SIGNING_SECRET_HERE');
