-- Don-Tech E-Commerce Database Schema
-- Import this into MySQL: mysql -u root -p < schema.sql

CREATE DATABASE IF NOT EXISTS dontech CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dontech;

-- ----------------------------------------------------------------------
-- Users (customers + admin)
-- ----------------------------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------
-- Categories
-- ----------------------------------------------------------------------
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE,
    slug VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

INSERT INTO categories (name, slug) VALUES
    ('Laptops', 'laptops'),
    ('Smartphones', 'smartphones'),
    ('Accessories', 'accessories'),
    ('Audio', 'audio');

-- ----------------------------------------------------------------------
-- Products
-- ----------------------------------------------------------------------
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    slug VARCHAR(170) NOT NULL UNIQUE,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    compare_at_price DECIMAL(10,2) DEFAULT NULL,
    stock INT NOT NULL DEFAULT 0,
    image_url VARCHAR(500) DEFAULT NULL,
    rating DECIMAL(2,1) DEFAULT 0.0,
    is_featured TINYINT(1) NOT NULL DEFAULT 0,
    is_new TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('active','draft','archived') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id),
    INDEX idx_category (category_id),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------
-- Cart (persistent, tied to user)
-- ----------------------------------------------------------------------
CREATE TABLE cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_user_product (user_id, product_id)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------
-- Wishlist
-- ----------------------------------------------------------------------
CREATE TABLE wishlist_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_user_product_wish (user_id, product_id)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------
-- Orders
-- ----------------------------------------------------------------------
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    order_number VARCHAR(40) NOT NULL UNIQUE,
    status ENUM('pending','paid','processing','shipped','completed','cancelled','failed') NOT NULL DEFAULT 'pending',
    subtotal DECIMAL(10,2) NOT NULL,
    shipping_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
    total DECIMAL(10,2) NOT NULL,
    payment_method ENUM('mpesa','card') NOT NULL,
    shipping_name VARCHAR(120) NOT NULL,
    shipping_phone VARCHAR(20) NOT NULL,
    shipping_address VARCHAR(255) NOT NULL,
    shipping_city VARCHAR(100) NOT NULL,
    notes VARCHAR(500) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_user (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------
-- Order items (snapshot of product at purchase time)
-- ----------------------------------------------------------------------
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(150) NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    quantity INT NOT NULL,
    line_total DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------
-- Payments (M-Pesa + Stripe transaction records)
-- ----------------------------------------------------------------------
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    method ENUM('mpesa','card') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('initiated','pending','success','failed') NOT NULL DEFAULT 'initiated',
    -- M-Pesa specific
    mpesa_checkout_request_id VARCHAR(100) DEFAULT NULL,
    mpesa_merchant_request_id VARCHAR(100) DEFAULT NULL,
    mpesa_receipt_number VARCHAR(50) DEFAULT NULL,
    mpesa_phone VARCHAR(20) DEFAULT NULL,
    -- Stripe specific
    stripe_payment_intent_id VARCHAR(120) DEFAULT NULL,
    stripe_client_secret VARCHAR(255) DEFAULT NULL,
    raw_response TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------
-- Sample products (so the storefront isn't empty on first run)
-- ----------------------------------------------------------------------
INSERT INTO products (category_id, name, slug, description, price, compare_at_price, stock, image_url, rating, is_featured, is_new, status) VALUES
((SELECT id FROM categories WHERE slug='laptops'), 'MacBook Pro M2', 'macbook-pro-m2', '13-inch, 8GB RAM, 256GB SSD', 1099.00, 1299.00, 12, 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&w=1470&q=80', 4.8, 1, 1, 'active'),
((SELECT id FROM categories WHERE slug='smartphones'), 'iPhone 14 Pro', 'iphone-14-pro', '128GB, Deep Purple', 999.00, NULL, 25, 'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?auto=format&fit=crop&w=1528&q=80', 4.9, 1, 1, 'active'),
((SELECT id FROM categories WHERE slug='audio'), 'Sony WH-1000XM4', 'sony-wh-1000xm4', 'Wireless Noise Cancelling Headphones', 278.00, NULL, 40, 'https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?auto=format&fit=crop&w=1589&q=80', 4.7, 1, 0, 'active'),
((SELECT id FROM categories WHERE slug='accessories'), 'Apple Watch Series 8', 'apple-watch-series-8', 'GPS, 41mm Starlight Aluminium Case', 319.00, 399.00, 18, 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=1528&q=80', 4.6, 1, 0, 'active'),
((SELECT id FROM categories WHERE slug='smartphones'), 'Samsung Galaxy S23 Ultra', 'samsung-galaxy-s23-ultra', 'Flagship smartphone bundle', 1099.00, 1299.00, 15, 'https://images.unsplash.com/photo-1678658716527-2e20a82a8c4a?auto=format&fit=crop&w=1470&q=80', 4.7, 1, 0, 'active');

-- ----------------------------------------------------------------------
-- Default admin user
-- Email: admin@dontech.local  Password: ChangeMe123!  (bcrypt hash below)
-- IMPORTANT: change this password immediately after first login.
-- ----------------------------------------------------------------------
INSERT INTO users (name, email, password_hash, role) VALUES
('Admin', 'admin@dontech.local', '$2y$10$U7xYqN/U0hZK2lXGjDyBceS7VRocZIEKbOiZtuWIabn.OHZrz/lsW', 'admin');
