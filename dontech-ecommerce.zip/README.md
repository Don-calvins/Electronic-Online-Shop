# Don-Tech — Electronics & Tech Services Store

A full e-commerce rebuild of the original single-page Don-Tech site:
**PHP + MySQL REST API** backend, **React (Vite)** frontend, with
**M-Pesa (Daraja STK Push)** and **Stripe (card)** checkout.

```
dontech/
├── backend/      PHP REST API + MySQL schema
└── frontend/     React (Vite + Tailwind v4) storefront
```

---

## 1. Backend setup (PHP + MySQL)

You said you already have a local PHP/MySQL environment (XAMPP, Laravel
Herd, Docker, etc.) — here's how to wire this project into it.

### 1.1 Copy the backend folder
Copy the `backend/` folder into your web server's document root, e.g.:

- **XAMPP**: `C:\xampp\htdocs\dontech\backend` (Windows) or `/Applications/XAMPP/htdocs/dontech/backend` (Mac)
- **Laravel Herd**: drop it in your sites folder and run `herd link dontech`

The API should then be reachable at something like
`http://localhost/dontech/backend/api/products.php`.

### 1.2 Import the database
```bash
mysql -u root -p < backend/schema.sql
```
This creates the `dontech` database, all tables, 5 sample products, and one
admin user.

**Default admin login:**
- Email: `admin@dontech.local`
- Password: `ChangeMe123!`

⚠️ **Change this password immediately** after your first login (there's no
"change password" UI yet — easiest is to log in as admin, then add a quick
endpoint, or update `password_hash` directly in the `users` table using
PHP's `password_hash()`).

### 1.3 Configure database credentials
Edit `backend/config/database.php`:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'dontech');
define('DB_USER', 'root');
define('DB_PASS', '');   // your MySQL password, if any
```

Also change `JWT_SECRET` in the same file to a long random string before
you deploy anywhere beyond your own machine.

### 1.4 Configure payments

**M-Pesa** — edit `backend/includes/mpesa.php`:
```php
define('MPESA_CONSUMER_KEY', '...');     // from developer.safaricom.co.ke
define('MPESA_CONSUMER_SECRET', '...');
define('MPESA_SHORTCODE', '...');        // sandbox default 174379 is pre-filled
define('MPESA_PASSKEY', '...');
define('MPESA_CALLBACK_URL', '...');     // MUST be a public HTTPS URL
```
Get sandbox credentials at https://developer.safaricom.co.ke — create an
app, enable "Lipa Na M-Pesa Online" (STK Push). The callback URL must be
publicly reachable; for local testing, use a tunnel like
[ngrok](https://ngrok.com) (`ngrok http 80`) and point
`MPESA_CALLBACK_URL` at the generated `https://...ngrok-free.app` URL.

**Stripe** — edit `backend/config/stripe.php`:
```php
define('STRIPE_SECRET_KEY', 'sk_test_...');
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_...');
define('STRIPE_WEBHOOK_SECRET', 'whsec_...');
```
Get test keys from https://dashboard.stripe.com/test/apikeys. For local
webhook testing, use the [Stripe CLI](https://stripe.com/docs/stripe-cli):
```bash
stripe listen --forward-to localhost/dontech/backend/api/stripe_webhook.php
```

Until you fill these in, checkout still works end-to-end except the final
payment confirmation step — see "What's stubbed" below.

### 1.5 Requirements
- PHP 8.0+ (uses typed properties, `str_starts_with`, etc.)
- PHP extensions: `pdo_mysql`, `curl`, `fileinfo` (all enabled by default in XAMPP)
- MySQL 5.7+ / MariaDB 10.3+

No Composer dependencies — JWT and Stripe/M-Pesa calls are hand-rolled with
cURL so the folder works as a drop-in without a build step.

---

## 2. Frontend setup (React + Vite)

```bash
cd frontend
npm install
npm run dev
```

Opens at `http://localhost:5173`.

### 2.1 Point it at your backend
`vite.config.js` proxies `/backend/*` requests to your PHP server:
```js
server: {
  proxy: {
    '/backend': {
      target: 'http://localhost/dontech', // <-- change this
      changeOrigin: true,
    },
  },
},
```
Update `target` to match wherever you copied the `backend/` folder in step 1.1.

### 2.2 Build for production
```bash
npm run build
```
Outputs static files to `frontend/dist/` — deploy these to any static host
(Netlify, Vercel, S3, or just `frontend/dist` copied next to `backend/` on
your PHP server). If you deploy frontend and backend on different domains,
add the frontend's origin to the `$allowedOrigins` array in
`backend/includes/cors.php`.

---

## 3. What's fully working

- User registration/login (JWT-based auth, bcrypt password hashing)
- Product catalog with category filtering, search, pagination
- Product detail pages
- Cart (persisted server-side per user) and wishlist
- Checkout flow: shipping form → order creation → payment
- M-Pesa STK Push: real Daraja API integration (sandbox-ready once you add
  credentials), live polling UI ("check your phone" screen), callback
  handler that marks orders paid
- Stripe: PaymentIntent creation wired up end-to-end on the backend
- Admin dashboard: product CRUD, order status management (protected by
  `role = admin` in the JWT)
- Image upload endpoint for product photos

## 4. What's stubbed / needs your input to finish

- **Stripe card collection UI**: the backend creates a real PaymentIntent
  and returns a `client_secret`, but the frontend doesn't yet mount
  [Stripe Elements](https://stripe.com/docs/payments/elements) to actually
  collect card details. Install `@stripe/stripe-js` and
  `@stripe/react-stripe-js`, then wire the `client_secret` from
  `Checkout.jsx` (search for the `card-pending` step) into a `<PaymentElement>`.
- **M-Pesa / Stripe credentials**: placeholders only — see section 1.4.
- **Email notifications**: order confirmations aren't emailed; add a mailer
  (e.g. PHPMailer) in `checkout.php` / `mpesa_callback.php` if you want this.
- **Newsletter signup**: the form on the homepage currently just
  acknowledges locally — no backend list exists yet.
- **Contact form**: the Contact page shows contact details but doesn't have
  a working form/backend yet.
- **Admin password change UI**: change the seeded admin password directly
  in the database for now (see 1.2).

## 5. Default credentials (sandbox/dev only — change before going live)

| Role  | Email                  | Password       |
|-------|-------------------------|----------------|
| Admin | admin@dontech.local     | ChangeMe123!   |

---

## 6. API reference (quick)

All endpoints live under `backend/api/`. Authenticated routes expect
`Authorization: Bearer <token>`.

| Endpoint | Method | Auth | Purpose |
|---|---|---|---|
| `register.php` | POST | – | Create account |
| `login.php` | POST | – | Get JWT |
| `me.php` | GET | ✓ | Current user |
| `products.php` | GET | – | List/search/filter products |
| `product.php?slug=` | GET | – | Single product |
| `categories.php` | GET | – | List categories |
| `cart.php` | GET/POST/DELETE | ✓ | View/add/remove cart items |
| `wishlist.php` | GET/POST/DELETE | ✓ | View/add/remove wishlist items |
| `checkout.php` | POST | ✓ | Create order from cart |
| `mpesa_stk.php` | POST | ✓ | Trigger STK push for an order |
| `mpesa_callback.php` | POST | – (called by Safaricom) | Payment result |
| `stripe_intent.php` | POST | ✓ | Create PaymentIntent |
| `stripe_webhook.php` | POST | – (called by Stripe) | Payment result |
| `order_status.php?order_id=` | GET | ✓ | Poll payment status |
| `orders.php` | GET | ✓ | Order history / single order |
| `admin_products.php` | GET/POST/PUT/DELETE | ✓ admin | Product CRUD |
| `admin_orders.php` | GET/PUT | ✓ admin | Order management |
| `upload_image.php` | POST | ✓ admin | Upload product image |
