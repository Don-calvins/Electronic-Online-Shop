import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    proxy: {
      '/backend': {
        target: 'http://localhost/dontech', // adjust to wherever your PHP backend is served (e.g. XAMPP htdocs path)
        changeOrigin: true,
      },
    },
  },
})
