import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-ink text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <i className="fas fa-laptop-code text-3xl text-primary" />
              <h3 className="text-2xl font-bold font-display">Don-Tech</h3>
            </div>
            <p className="text-gray-400 mb-4">
              Premium electronics and professional tech services, built for Kenya.
            </p>
            <div className="flex space-x-4">
              {['facebook-f', 'twitter', 'instagram', 'linkedin-in'].map((icon) => (
                <a key={icon} href="#" className="text-gray-400 hover:text-white" aria-label={icon}>
                  <i className={`fab fa-${icon}`} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-gray-400">
              <li><Link to="/" className="hover:text-white">Home</Link></li>
              <li><Link to="/products" className="hover:text-white">Products</Link></li>
              <li><Link to="/#services" className="hover:text-white">Services</Link></li>
              <li><Link to="/contact" className="hover:text-white">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4">Customer Service</h4>
            <ul className="space-y-2 text-gray-400">
              <li><Link to="/orders" className="hover:text-white">My Orders</Link></li>
              <li><Link to="/wishlist" className="hover:text-white">Wishlist</Link></li>
              <li><Link to="/cart" className="hover:text-white">Cart</Link></li>
              <li><Link to="/contact" className="hover:text-white">FAQs</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-4">Contact Info</h4>
            <ul className="space-y-3 text-gray-400">
              <li className="flex items-start"><i className="fas fa-map-marker-alt mt-1 mr-3 text-primary" /> 123 Don State, Nairobi, Kenya</li>
              <li className="flex items-center"><i className="fas fa-phone-alt mr-3 text-primary" /> +254 748 480 742</li>
              <li className="flex items-center"><i className="fas fa-envelope mr-3 text-primary" /> odhiambodon@gmail.com</li>
              <li className="flex items-center"><i className="fas fa-clock mr-3 text-primary" /> Mon–Fri: 9AM–6PM</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 mb-4 md:mb-0">© {new Date().getFullYear()} Don-Tech. All rights reserved.</p>
          <div className="flex space-x-6 text-gray-400">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
