import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/products', label: 'Products' },
  { to: '/#services', label: 'Services' },
  { to: '/contact', label: 'Contact' },
];

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { user, logout, isAdmin } = useAuth();
  const { itemCount } = useCart();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    setMenuOpen(false);
    navigate('/');
  }

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="bg-ink text-white py-2 px-4 text-xs hidden sm:block">
        <div className="container mx-auto flex justify-between items-center">
          <span>
            <i className="fas fa-phone-alt mr-1" /> +254 748 480 742
          </span>
          <span>
            <i className="fas fa-envelope mr-1" /> odhiambodon@gmail.com
          </span>
        </div>
      </div>

      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link to="/" className="flex items-center space-x-2">
          <i className="fas fa-laptop-code text-3xl text-primary" />
          <span className="text-2xl font-bold font-display">Don-Tech</span>
        </Link>

        <nav className="hidden md:flex items-center space-x-8">
          <ul className="flex space-x-6">
            {navLinks.map((link) => (
              <li key={link.label}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) =>
                    `font-medium hover:text-primary transition ${isActive ? 'text-primary' : 'text-ink'}`
                  }
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>

          <div className="flex items-center space-x-5">
            <Link to="/wishlist" className="relative" aria-label="Wishlist">
              <i className="fas fa-heart text-xl text-ink" />
            </Link>
            <Link to="/cart" className="relative" aria-label="Cart">
              <i className="fas fa-shopping-cart text-xl text-ink" />
              {itemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {itemCount}
                </span>
              )}
            </Link>

            {user ? (
              <div className="relative group">
                <button className="flex items-center gap-2 font-medium">
                  <i className="fas fa-user-circle text-xl" />
                  {user.name.split(' ')[0]}
                </button>
                <div className="absolute right-0 mt-2 w-44 bg-white rounded-md shadow-lg py-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                  <Link to="/orders" className="block px-4 py-2 text-sm hover:bg-gray-50">My Orders</Link>
                  {isAdmin && (
                    <Link to="/admin" className="block px-4 py-2 text-sm hover:bg-gray-50">Admin Dashboard</Link>
                  )}
                  <button onClick={handleLogout} className="block w-full text-left px-4 py-2 text-sm hover:bg-gray-50">
                    Sign Out
                  </button>
                </div>
              </div>
            ) : (
              <Link to="/login" className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary-dark transition">
                Sign In
              </Link>
            )}
          </div>
        </nav>

        <button
          className="md:hidden text-ink"
          onClick={() => setMenuOpen((o) => !o)}
          aria-label="Toggle menu"
          aria-expanded={menuOpen}
        >
          <i className={`fas ${menuOpen ? 'fa-times' : 'fa-bars'} text-2xl`} />
        </button>
      </div>

      {menuOpen && (
        <div className="md:hidden bg-white shadow-lg absolute w-full z-50 border-t">
          <div className="container mx-auto px-4 py-4">
            <ul className="space-y-3">
              {navLinks.map((link) => (
                <li key={link.label}>
                  <Link to={link.to} onClick={() => setMenuOpen(false)} className="block py-2 font-medium">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
            <div className="mt-4 pt-4 border-t flex items-center justify-between">
              <div className="flex items-center space-x-5">
                <Link to="/wishlist" onClick={() => setMenuOpen(false)}>
                  <i className="fas fa-heart text-xl" />
                </Link>
                <Link to="/cart" onClick={() => setMenuOpen(false)} className="relative">
                  <i className="fas fa-shopping-cart text-xl" />
                  {itemCount > 0 && (
                    <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                      {itemCount}
                    </span>
                  )}
                </Link>
              </div>
              {user ? (
                <button onClick={handleLogout} className="text-sm font-medium text-primary">Sign Out</button>
              ) : (
                <Link to="/login" onClick={() => setMenuOpen(false)} className="bg-primary text-white px-4 py-2 rounded-md">
                  Sign In
                </Link>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
