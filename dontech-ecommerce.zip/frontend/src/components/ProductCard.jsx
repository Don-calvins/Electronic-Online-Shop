import { Link } from 'react-router-dom';
import { useState } from 'react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function ProductCard({ product }) {
  const { addToCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [adding, setAdding] = useState(false);
  const [justAdded, setJustAdded] = useState(false);

  async function handleAddToCart(e) {
    e.preventDefault();
    if (!user) {
      navigate('/login');
      return;
    }
    setAdding(true);
    try {
      await addToCart(product.id, 1);
      setJustAdded(true);
      setTimeout(() => setJustAdded(false), 1500);
    } catch (err) {
      alert(err.message);
    } finally {
      setAdding(false);
    }
  }

  const onSale = product.compare_at_price && Number(product.compare_at_price) > Number(product.price);
  const discountPct = onSale
    ? Math.round((1 - Number(product.price) / Number(product.compare_at_price)) * 100)
    : null;

  return (
    <Link
      to={`/products/${product.slug}`}
      className="card-hover bg-white rounded-lg overflow-hidden shadow-md block"
    >
      <div className="relative">
        <img src={product.image_url} alt={product.name} className="w-full h-56 object-cover" loading="lazy" />
        {product.is_new === 1 && (
          <span className="absolute top-2 left-2 bg-primary text-white text-xs font-bold px-2 py-1 rounded">NEW</span>
        )}
        {onSale && (
          <span className="absolute top-2 right-2 bg-accent text-white text-xs font-bold px-2 py-1 rounded">
            -{discountPct}%
          </span>
        )}
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start mb-1">
          <h3 className="font-bold text-base leading-snug">{product.name}</h3>
          <div className="flex items-center shrink-0 ml-2">
            <i className="fas fa-star text-yellow-400 text-sm" />
            <span className="ml-1 text-sm">{Number(product.rating).toFixed(1)}</span>
          </div>
        </div>
        <p className="text-gray-500 text-sm mb-3 line-clamp-1">{product.category_name}</p>
        <div className="flex justify-between items-center">
          <div>
            {onSale && (
              <span className="text-gray-400 line-through text-sm mr-2">${Number(product.compare_at_price).toFixed(2)}</span>
            )}
            <span className="text-primary font-bold">${Number(product.price).toFixed(2)}</span>
          </div>
          <button
            onClick={handleAddToCart}
            disabled={adding || product.stock < 1}
            className={`p-2 rounded-full text-white transition disabled:opacity-50 ${
              justAdded ? 'bg-success' : 'bg-primary hover:bg-primary-dark'
            }`}
            aria-label={`Add ${product.name} to cart`}
          >
            <i className={`fas ${justAdded ? 'fa-check' : 'fa-shopping-cart'}`} />
          </button>
        </div>
        {product.stock < 1 && <p className="text-xs text-red-500 mt-2">Out of stock</p>}
      </div>
    </Link>
  );
}
