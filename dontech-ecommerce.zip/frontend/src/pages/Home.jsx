import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../lib/api';
import ProductCard from '../components/ProductCard';

const services = [
  { icon: 'fa-laptop-medical', title: 'Device Repair', desc: 'Fast, reliable repairs for smartphones, tablets, and laptops, using genuine parts.' },
  { icon: 'fa-shield-virus', title: 'Virus Removal', desc: 'Protect your devices from malware, viruses, and spyware.' },
  { icon: 'fa-database', title: 'Data Recovery', desc: 'Recover deleted photos, documents, and other important files.' },
  { icon: 'fa-network-wired', title: 'Network Setup', desc: 'Home and office network installation, configuration, and troubleshooting.' },
  { icon: 'fa-cloud', title: 'Cloud Services', desc: 'Set up cloud storage for seamless access across all your devices.' },
  { icon: 'fa-user-cog', title: 'Tech Support', desc: 'Personalized support for all your devices, remote or in-person.' },
];

const testimonials = [
  { name: 'Sarah Johnson', img: 'women/32', rating: 5, text: 'Bought my MacBook Pro from Don-Tech and the service was exceptional. Fast shipping and great support setting it up.' },
  { name: 'Michael Chen', img: 'men/75', rating: 5, text: 'Their data recovery service saved my business. Thought I lost months of work, but their team recovered everything within 24 hours.' },
  { name: 'Emily Rodriguez', img: 'women/68', rating: 4.5, text: 'The network setup service was worth every shilling. My home office has never worked better.' },
];

function Stars({ rating }) {
  const full = Math.floor(rating);
  const half = rating % 1 !== 0;
  return (
    <div className="flex text-yellow-400">
      {Array.from({ length: full }).map((_, i) => <i key={i} className="fas fa-star" />)}
      {half && <i className="fas fa-star-half-alt" />}
    </div>
  );
}

export default function Home() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  useEffect(() => {
    api.getProducts({ featured: 1, per_page: 4 })
      .then((data) => setProducts(data.products))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  function handleSubscribe(e) {
    e.preventDefault();
    if (!email) return;
    // No newsletter backend yet — acknowledge locally so the form isn't a dead end.
    setSubscribed(true);
    setEmail('');
  }

  return (
    <>
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary to-primary-dark text-white py-20">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center gap-10">
          <div className="md:w-1/2">
            <h1 className="text-4xl md:text-5xl font-bold font-display mb-6 leading-tight">
              Premium Electronics &amp; Tech Services
            </h1>
            <p className="text-xl mb-8 opacity-90">
              The latest gadgets and professional tech support, with M-Pesa checkout built in.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/products" className="bg-white text-primary font-bold px-6 py-3 rounded-md hover:bg-gray-100 transition text-center">
                Shop Now
              </Link>
              <a href="#services" className="border-2 border-white text-white font-bold px-6 py-3 rounded-md hover:bg-white hover:text-primary transition text-center">
                Our Services
              </a>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <img
              src="https://images.unsplash.com/photo-1550009158-9ebf691dd9eb?auto=format&fit=crop&w=1470&q=80"
              alt="Electronics on display"
              className="rounded-lg shadow-2xl max-w-full h-auto"
            />
          </div>
        </div>
      </section>

      {/* Trust strip */}
      <section className="py-14 bg-white">
        <div className="container mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            ['fa-shipping-fast', 'Free Shipping', 'Free delivery on orders over $99'],
            ['fa-undo-alt', 'Easy Returns', '30-day return policy'],
            ['fa-headset', '24/7 Support', 'Dedicated customer support'],
            ['fa-shield-alt', 'Secure Payment', 'M-Pesa & card, both encrypted'],
          ].map(([icon, title, desc]) => (
            <div key={title} className="flex flex-col items-center text-center">
              <div className="bg-blue-100 p-4 rounded-full mb-4">
                <i className={`fas ${icon} text-primary text-2xl`} />
              </div>
              <h3 className="font-bold mb-1">{title}</h3>
              <p className="text-gray-600 text-sm">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Featured products */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold font-display mb-3">Featured Products</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Our curated selection of premium electronics and gadgets</p>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="bg-white rounded-lg h-80 animate-pulse" />
              ))}
            </div>
          ) : products.length === 0 ? (
            <p className="text-center text-gray-500">
              No products yet — add some from the admin dashboard once your database is seeded.
            </p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {products.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          )}

          <div className="text-center mt-12">
            <Link to="/products" className="inline-block bg-primary text-white px-6 py-3 rounded-md hover:bg-primary-dark transition">
              View All Products
            </Link>
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold font-display mb-3">Our Tech Services</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Professional solutions to keep your devices running smoothly</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((s) => (
              <div key={s.title} className="p-8 rounded-lg shadow-md hover:bg-blue-50 transition">
                <div className="text-primary text-4xl mb-4"><i className={`fas ${s.icon}`} /></div>
                <h3 className="font-bold text-xl mb-3">{s.title}</h3>
                <p className="text-gray-600 mb-4">{s.desc}</p>
                <Link to="/contact" className="text-primary font-medium inline-flex items-center">
                  Get in touch <i className="fas fa-arrow-right ml-2" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold font-display mb-3">What Our Customers Say</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((t) => (
              <div key={t.name} className="bg-white p-8 rounded-lg shadow-sm">
                <div className="flex items-center mb-4">
                  <img src={`https://randomuser.me/api/portraits/${t.img}.jpg`} alt={t.name} className="h-12 w-12 rounded-full" />
                  <div className="ml-4">
                    <h4 className="font-bold">{t.name}</h4>
                    <Stars rating={t.rating} />
                  </div>
                </div>
                <p className="text-gray-600">&ldquo;{t.text}&rdquo;</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-primary-dark text-white">
        <div className="container mx-auto px-4 max-w-3xl text-center">
          <h2 className="text-3xl font-bold font-display mb-4">Stay Updated</h2>
          <p className="mb-8 opacity-90">Subscribe for tech news, exclusive deals, and service offers.</p>
          {subscribed ? (
            <p className="bg-white/10 rounded-md py-3 px-4 inline-block">You're on the list — thanks for subscribing.</p>
          ) : (
            <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-4 max-w-xl mx-auto">
              <label htmlFor="newsletter-email" className="sr-only">Email address</label>
              <input
                id="newsletter-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email address"
                className="flex-grow px-4 py-3 rounded-md text-ink focus:outline-none focus:ring-2 focus:ring-accent"
              />
              <button type="submit" className="bg-accent hover:bg-accent-dark px-6 py-3 rounded-md font-medium transition">
                Subscribe
              </button>
            </form>
          )}
        </div>
      </section>
    </>
  );
}
