import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';

const POLL_INTERVAL_MS = 3000;
const POLL_TIMEOUT_MS = 90000;

export default function Checkout() {
  const { items, subtotal, refreshCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [shipping, setShipping] = useState({
    shipping_name: user?.name || '',
    shipping_phone: '',
    shipping_address: '',
    shipping_city: '',
    notes: '',
  });
  const [paymentMethod, setPaymentMethod] = useState('mpesa');
  const [step, setStep] = useState('form'); // form | mpesa-waiting | mpesa-success | mpesa-failed | card-pending | error
  const [error, setError] = useState(null);
  const [order, setOrder] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  function update(field) {
    return (e) => setShipping((s) => ({ ...s, [field]: e.target.value }));
  }

  const shippingFee = subtotal >= 99 ? 0 : 9.99;
  const total = subtotal + shippingFee;

  async function pollOrderStatus(orderId) {
    const start = Date.now();
    while (Date.now() - start < POLL_TIMEOUT_MS) {
      await new Promise((r) => setTimeout(r, POLL_INTERVAL_MS));
      try {
        const { order: updated } = await api.getOrderStatus(orderId);
        if (updated.payment_status === 'success') {
          setStep('mpesa-success');
          await refreshCart();
          return;
        }
        if (updated.payment_status === 'failed') {
          setStep('mpesa-failed');
          return;
        }
      } catch {
        // keep polling — a transient error here shouldn't abort the wait
      }
    }
    // Timed out — leave it as pending; the callback may still arrive late
    setStep('mpesa-failed');
    setError('We did not receive confirmation in time. If you completed the M-Pesa prompt, your order may still go through — check My Orders shortly.');
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      const { order: newOrder } = await api.checkout({ payment_method: paymentMethod, ...shipping });
      setOrder(newOrder);

      if (paymentMethod === 'mpesa') {
        setStep('mpesa-waiting');
        await api.mpesaStk({ order_id: newOrder.id, phone: shipping.shipping_phone });
        pollOrderStatus(newOrder.id);
      } else {
        // Card flow: create the PaymentIntent. Actual card collection happens
        // via Stripe.js + Elements on the client using the returned client_secret —
        // wire up @stripe/stripe-js here once you have real Stripe keys configured.
        const { client_secret } = await api.stripeIntent({ order_id: newOrder.id });
        setStep('card-pending');
        console.log('Stripe client_secret ready for Elements:', client_secret);
      }
    } catch (err) {
      setError(err.message);
      setStep('error');
    } finally {
      setSubmitting(false);
    }
  }

  if (items.length === 0 && step === 'form') {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <p className="text-gray-600 mb-4">Your cart is empty.</p>
        <Link to="/products" className="text-primary font-medium">Browse products</Link>
      </div>
    );
  }

  if (step === 'mpesa-waiting') {
    return (
      <div className="container mx-auto px-4 py-20 max-w-md text-center">
        <div className="relative inline-flex items-center justify-center w-20 h-20 mb-6">
          <div className="absolute inset-0 rounded-full bg-primary/10 pulse-ring" />
          <i className="fas fa-mobile-alt text-4xl text-primary relative" />
        </div>
        <h1 className="text-2xl font-bold font-display mb-2">Check your phone</h1>
        <p className="text-gray-600 mb-1">
          We sent an M-Pesa payment request to <strong>{shipping.shipping_phone}</strong>.
        </p>
        <p className="text-gray-600 mb-6">Enter your M-Pesa PIN to complete the payment of <strong>${total.toFixed(2)}</strong>.</p>
        <p className="text-sm text-gray-400">Waiting for confirmation… this can take up to a minute.</p>
      </div>
    );
  }

  if (step === 'mpesa-success') {
    return (
      <div className="container mx-auto px-4 py-20 max-w-md text-center">
        <i className="fas fa-check-circle text-5xl text-success mb-4" />
        <h1 className="text-2xl font-bold font-display mb-2">Payment received</h1>
        <p className="text-gray-600 mb-6">
          Order <strong>{order?.order_number}</strong> is confirmed. We'll start processing it right away.
        </p>
        <Link to="/orders" className="bg-primary text-white px-6 py-3 rounded-md hover:bg-primary-dark transition">
          View My Orders
        </Link>
      </div>
    );
  }

  if (step === 'mpesa-failed') {
    return (
      <div className="container mx-auto px-4 py-20 max-w-md text-center">
        <i className="fas fa-times-circle text-5xl text-red-400 mb-4" />
        <h1 className="text-2xl font-bold font-display mb-2">Payment not completed</h1>
        <p className="text-gray-600 mb-6">{error || 'The M-Pesa payment was not completed or was cancelled.'}</p>
        <button onClick={() => setStep('form')} className="bg-primary text-white px-6 py-3 rounded-md hover:bg-primary-dark transition">
          Try Again
        </button>
      </div>
    );
  }

  if (step === 'card-pending') {
    return (
      <div className="container mx-auto px-4 py-20 max-w-md text-center">
        <i className="fas fa-credit-card text-5xl text-primary mb-4" />
        <h1 className="text-2xl font-bold font-display mb-2">Card payment ready</h1>
        <p className="text-gray-600 mb-2">
          Order <strong>{order?.order_number}</strong> is awaiting payment.
        </p>
        <p className="text-gray-500 text-sm mb-6">
          The Stripe PaymentIntent was created. To finish wiring this up, mount Stripe Elements with the
          returned <code className="bg-gray-100 px-1 rounded">client_secret</code> to collect card details
          (see the console log, and the comment in Checkout.jsx).
        </p>
        <Link to="/orders" className="text-primary font-medium">View My Orders</Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold font-display mb-8">Checkout</h1>

      {error && step === 'error' && (
        <div className="max-w-2xl mb-6 px-4 py-3 rounded-md bg-red-50 text-red-600 text-sm">{error}</div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <form onSubmit={handleSubmit} className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="font-bold text-lg mb-4">Shipping Details</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label htmlFor="shipping_name" className="block text-sm font-medium mb-1">Full name</label>
                <input id="shipping_name" required value={shipping.shipping_name} onChange={update('shipping_name')}
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary" />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="shipping_phone" className="block text-sm font-medium mb-1">Phone number</label>
                <input id="shipping_phone" type="tel" required placeholder="07XXXXXXXX"
                  value={shipping.shipping_phone} onChange={update('shipping_phone')}
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary" />
                {paymentMethod === 'mpesa' && (
                  <p className="text-xs text-gray-500 mt-1">This number receives the M-Pesa payment prompt.</p>
                )}
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="shipping_address" className="block text-sm font-medium mb-1">Address</label>
                <input id="shipping_address" required value={shipping.shipping_address} onChange={update('shipping_address')}
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary" />
              </div>
              <div>
                <label htmlFor="shipping_city" className="block text-sm font-medium mb-1">City</label>
                <input id="shipping_city" required value={shipping.shipping_city} onChange={update('shipping_city')}
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary" />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="notes" className="block text-sm font-medium mb-1">Order notes (optional)</label>
                <textarea id="notes" rows={2} value={shipping.notes} onChange={update('notes')}
                  className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="font-bold text-lg mb-4">Payment Method</h2>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setPaymentMethod('mpesa')}
                className={`border-2 rounded-lg p-4 text-left transition ${paymentMethod === 'mpesa' ? 'border-primary bg-blue-50' : 'border-gray-200'}`}
              >
                <i className="fas fa-mobile-alt text-2xl text-success mb-2 block" />
                <span className="font-medium">M-Pesa</span>
                <p className="text-xs text-gray-500 mt-1">Pay via STK push to your phone</p>
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`border-2 rounded-lg p-4 text-left transition ${paymentMethod === 'card' ? 'border-primary bg-blue-50' : 'border-gray-200'}`}
              >
                <i className="fas fa-credit-card text-2xl text-primary mb-2 block" />
                <span className="font-medium">Card</span>
                <p className="text-xs text-gray-500 mt-1">Visa, Mastercard via Stripe</p>
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-primary text-white py-3 rounded-md font-medium hover:bg-primary-dark transition disabled:opacity-50"
          >
            {submitting ? 'Placing order…' : `Pay $${total.toFixed(2)}`}
          </button>
        </form>

        <div className="bg-white rounded-lg shadow-sm p-6 h-fit">
          <h2 className="font-bold text-lg mb-4">Order Summary</h2>
          <div className="space-y-3 mb-4 max-h-64 overflow-y-auto">
            {items.map((item) => (
              <div key={item.cart_item_id} className="flex justify-between text-sm">
                <span className="text-gray-600">{item.name} × {item.quantity}</span>
                <span>${(item.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
          </div>
          <div className="space-y-2 text-sm border-t pt-4 mb-4">
            <div className="flex justify-between"><span className="text-gray-600">Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between">
              <span className="text-gray-600">Shipping</span>
              <span>{shippingFee === 0 ? 'Free' : `$${shippingFee.toFixed(2)}`}</span>
            </div>
          </div>
          <div className="flex justify-between font-bold text-lg border-t pt-4">
            <span>Total</span><span>${total.toFixed(2)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
