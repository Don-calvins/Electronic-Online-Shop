import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

export default function ProductDetail() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { addToCart } = useCart();

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [adding, setAdding] = useState(false);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    api.getProduct(slug)
      .then((data) => setProduct(data.product))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [slug]);

  async function handleAddToCart() {
    if (!user) {
      navigate('/login');
      return;
    }
    setAdding(true);
    setMessage(null);
    try {
      await addToCart(product.id, quantity);
      setMessage({ type: 'success', text: `Added ${quantity} to cart.` });
    } catch (err) {
      setMessage({ type: 'error', text: err.message });
    } finally {
      setAdding(false);
    }
  }

  async function handleWishlist() {
    if (!user) {
      navigate('/login');
      return;
    }
    try {
      await api.addToWishlist(product.id);
      setMessage({ type: 'success', text: 'Added to wishlist.' });
    } catch (err) {
      setMessage({ type: 'error', text: err.message });
    }
  }

  if (loading) {
    return <div className="container mx-auto px-4 py-20 text-center text-gray-500">Loading…</div>;
  }

  if (error || !product) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <p className="text-gray-600 mb-4">{error || 'Product not found.'}</p>
        <Link to="/products" className="text-primary font-medium">Back to all products</Link>
      </div>
    );
  }

  const onSale = product.compare_at_price && Number(product.compare_at_price) > Number(product.price);

  return (
    <div className="container mx-auto px-4 py-12">
      <nav className="text-sm text-gray-500 mb-8">
        <Link to="/products" className="hover:text-primary">Products</Link>
        <span className="mx-2">/</span>
        <span>{product.category_name}</span>
      </nav>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div>
          <img src={product.image_url} alt={product.name} className="w-full rounded-lg shadow-md object-cover" />
        </div>

        <div>
          <h1 className="text-3xl font-bold font-display mb-2">{product.name}</h1>
          <div className="flex items-center gap-2 mb-4">
            <i className="fas fa-star text-yellow-400" />
            <span>{Number(product.rating).toFixed(1)}</span>
            <span className="text-gray-400">·</span>
            <span className={product.stock > 0 ? 'text-success' : 'text-red-500'}>
              {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
            </span>
          </div>

          <div className="mb-6">
            {onSale && (
              <span className="text-gray-400 line-through text-lg mr-3">${Number(product.compare_at_price).toFixed(2)}</span>
            )}
            <span className="text-3xl font-bold text-primary">${Number(product.price).toFixed(2)}</span>
          </div>

          <p className="text-gray-600 mb-8 leading-relaxed">{product.description}</p>

          {message && (
            <div className={`mb-4 px-4 py-3 rounded-md text-sm ${message.type === 'success' ? 'bg-green-50 text-success' : 'bg-red-50 text-red-600'}`}>
              {message.text}
            </div>
          )}

          <div className="flex items-center gap-4 mb-6">
            <div className="flex items-center border rounded-md">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="px-3 py-2 hover:bg-gray-50"
                aria-label="Decrease quantity"
              >
                <i className="fas fa-minus text-xs" />
              </button>
              <span className="px-4 font-medium">{quantity}</span>
              <button
                onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                className="px-3 py-2 hover:bg-gray-50"
                aria-label="Increase quantity"
              >
                <i className="fas fa-plus text-xs" />
              </button>
            </div>

            <button
              onClick={handleAddToCart}
              disabled={adding || product.stock < 1}
              className="flex-1 bg-primary text-white py-3 rounded-md font-medium hover:bg-primary-dark transition disabled:opacity-50"
            >
              {adding ? 'Adding…' : 'Add to Cart'}
            </button>

            <button
              onClick={handleWishlist}
              className="p-3 border rounded-md hover:bg-gray-50"
              aria-label="Add to wishlist"
            >
              <i className="fas fa-heart text-primary" />
            </button>
          </div>

          <ul className="text-sm text-gray-500 space-y-2 border-t pt-6">
            <li><i className="fas fa-shipping-fast mr-2 text-primary" /> Free shipping on orders over $99</li>
            <li><i className="fas fa-undo-alt mr-2 text-primary" /> 30-day return policy</li>
            <li><i className="fas fa-shield-alt mr-2 text-primary" /> Pay securely with M-Pesa or card</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
