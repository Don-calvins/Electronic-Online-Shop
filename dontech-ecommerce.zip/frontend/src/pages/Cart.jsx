import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useState } from 'react';

export default function Cart() {
  const { items, subtotal, loading, removeFromCart, refreshCart } = useCart();
  const navigate = useNavigate();
  const [removingId, setRemovingId] = useState(null);

  async function handleRemove(productId) {
    setRemovingId(productId);
    try {
      await removeFromCart(productId);
    } finally {
      setRemovingId(null);
    }
  }

  if (loading && items.length === 0) {
    return <div className="container mx-auto px-4 py-20 text-center text-gray-500">Loading your cart…</div>;
  }

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <i className="fas fa-shopping-cart text-5xl text-gray-300 mb-4" />
        <h1 className="text-2xl font-bold font-display mb-2">Your cart is empty</h1>
        <p className="text-gray-600 mb-6">Browse our products and add something you like.</p>
        <Link to="/products" className="bg-primary text-white px-6 py-3 rounded-md hover:bg-primary-dark transition">
          Shop Products
        </Link>
      </div>
    );
  }

  const shippingFee = subtotal >= 99 ? 0 : 9.99;
  const total = subtotal + shippingFee;

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold font-display mb-8">Your Cart</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          {items.map((item) => (
            <div key={item.cart_item_id} className="bg-white rounded-lg shadow-sm p-4 flex gap-4 items-center">
              <img src={item.image_url} alt={item.name} className="w-20 h-20 object-cover rounded-md" />
              <div className="flex-grow">
                <Link to={`/products/${item.slug}`} className="font-bold hover:text-primary">{item.name}</Link>
                <p className="text-gray-500 text-sm">Qty: {item.quantity}</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-primary">${(item.price * item.quantity).toFixed(2)}</p>
                <button
                  onClick={() => handleRemove(item.product_id)}
                  disabled={removingId === item.product_id}
                  className="text-sm text-red-500 hover:text-red-700 mt-1 disabled:opacity-50"
                >
                  {removingId === item.product_id ? 'Removing…' : 'Remove'}
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6 h-fit">
          <h2 className="font-bold text-lg mb-4">Order Summary</h2>
          <div className="space-y-2 text-sm mb-4">
            <div className="flex justify-between"><span className="text-gray-600">Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
            <div className="flex justify-between">
              <span className="text-gray-600">Shipping</span>
              <span>{shippingFee === 0 ? 'Free' : `$${shippingFee.toFixed(2)}`}</span>
            </div>
          </div>
          <div className="flex justify-between font-bold text-lg border-t pt-4 mb-6">
            <span>Total</span><span>${total.toFixed(2)}</span>
          </div>
          <button
            onClick={() => navigate('/checkout')}
            className="w-full bg-primary text-white py-3 rounded-md font-medium hover:bg-primary-dark transition"
          >
            Proceed to Checkout
          </button>
        </div>
      </div>
    </div>
  );
}
