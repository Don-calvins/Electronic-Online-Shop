import { useEffect, useState } from 'react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { Navigate } from 'react-router-dom';

const emptyForm = {
  id: null, name: '', category_id: '', price: '', compare_at_price: '',
  stock: '', image_url: '', description: '', is_featured: false, is_new: false, status: 'active',
};

function AdminProducts() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  async function loadProducts() {
    const token = localStorage.getItem('dontech_token');
    const res = await fetch('/backend/api/admin_products.php', {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = await res.json();
    setProducts(data.products || []);
  }

  useEffect(() => {
    Promise.all([loadProducts(), api.getCategories().then((d) => setCategories(d.categories))])
      .finally(() => setLoading(false));
  }, []);

  function update(field) {
    return (e) => {
      const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
      setForm((f) => ({ ...f, [field]: value }));
    };
  }

  async function adminRequest(method, body) {
    const token = localStorage.getItem('dontech_token');
    const res = await fetch('/backend/api/admin_products.php', {
      method,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    try {
      if (editing) {
        await adminRequest('PUT', form);
      } else {
        await adminRequest('POST', form);
      }
      setForm(emptyForm);
      setEditing(false);
      await loadProducts();
    } catch (err) {
      setError(err.message);
    }
  }

  function startEdit(p) {
    setForm({
      id: p.id, name: p.name, category_id: p.category_id, price: p.price,
      compare_at_price: p.compare_at_price || '', stock: p.stock, image_url: p.image_url || '',
      description: p.description || '', is_featured: !!p.is_featured, is_new: !!p.is_new, status: p.status,
    });
    setEditing(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function handleArchive(id) {
    if (!confirm('Archive this product? It will no longer appear in the storefront.')) return;
    const token = localStorage.getItem('dontech_token');
    await fetch(`/backend/api/admin_products.php?id=${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    await loadProducts();
  }

  if (loading) return <p className="text-gray-500">Loading products…</p>;

  return (
    <div>
      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <h2 className="font-bold text-lg mb-4">{editing ? 'Edit Product' : 'Add Product'}</h2>
        {error && <div className="mb-4 px-4 py-2 rounded-md bg-red-50 text-red-600 text-sm">{error}</div>}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          <input required placeholder="Name" value={form.name} onChange={update('name')} className="px-3 py-2 border rounded-md" />
          <select required value={form.category_id} onChange={update('category_id')} className="px-3 py-2 border rounded-md">
            <option value="">Select category</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input required type="number" step="0.01" placeholder="Price" value={form.price} onChange={update('price')} className="px-3 py-2 border rounded-md" />
          <input type="number" step="0.01" placeholder="Compare-at price (optional)" value={form.compare_at_price} onChange={update('compare_at_price')} className="px-3 py-2 border rounded-md" />
          <input required type="number" placeholder="Stock" value={form.stock} onChange={update('stock')} className="px-3 py-2 border rounded-md" />
          <input placeholder="Image URL" value={form.image_url} onChange={update('image_url')} className="px-3 py-2 border rounded-md" />
          <textarea placeholder="Description" value={form.description} onChange={update('description')} className="px-3 py-2 border rounded-md sm:col-span-2" rows={3} />
          <label className="flex items-center gap-2"><input type="checkbox" checked={form.is_featured} onChange={update('is_featured')} /> Featured</label>
          <label className="flex items-center gap-2"><input type="checkbox" checked={form.is_new} onChange={update('is_new')} /> Mark as new</label>
        </div>
        <div className="flex gap-3">
          <button type="submit" className="bg-primary text-white px-5 py-2 rounded-md hover:bg-primary-dark transition">
            {editing ? 'Save Changes' : 'Add Product'}
          </button>
          {editing && (
            <button type="button" onClick={() => { setForm(emptyForm); setEditing(false); }} className="px-5 py-2 border rounded-md">
              Cancel
            </button>
          )}
        </div>
      </form>

      <div className="bg-white rounded-lg shadow-sm overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-left">
            <tr>
              <th className="p-3">Name</th><th className="p-3">Price</th><th className="p-3">Stock</th>
              <th className="p-3">Status</th><th className="p-3"></th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} className="border-t">
                <td className="p-3">{p.name}</td>
                <td className="p-3">${Number(p.price).toFixed(2)}</td>
                <td className="p-3">{p.stock}</td>
                <td className="p-3 capitalize">{p.status}</td>
                <td className="p-3 text-right space-x-3">
                  <button onClick={() => startEdit(p)} className="text-primary font-medium">Edit</button>
                  <button onClick={() => handleArchive(p.id)} className="text-red-500 font-medium">Archive</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  async function loadOrders() {
    const token = localStorage.getItem('dontech_token');
    const res = await fetch('/backend/api/admin_orders.php', { headers: { Authorization: `Bearer ${token}` } });
    const data = await res.json();
    setOrders(data.orders || []);
  }

  useEffect(() => { loadOrders().finally(() => setLoading(false)); }, []);

  async function updateStatus(id, status) {
    const token = localStorage.getItem('dontech_token');
    await fetch('/backend/api/admin_orders.php', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ id, status }),
    });
    await loadOrders();
  }

  if (loading) return <p className="text-gray-500">Loading orders…</p>;

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-gray-50 text-left">
          <tr>
            <th className="p-3">Order #</th><th className="p-3">Customer</th><th className="p-3">Total</th>
            <th className="p-3">Method</th><th className="p-3">Status</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((o) => (
            <tr key={o.id} className="border-t">
              <td className="p-3">{o.order_number}</td>
              <td className="p-3">{o.customer_email}</td>
              <td className="p-3">${Number(o.total).toFixed(2)}</td>
              <td className="p-3 uppercase text-xs">{o.payment_method}</td>
              <td className="p-3">
                <select value={o.status} onChange={(e) => updateStatus(o.id, e.target.value)} className="border rounded-md px-2 py-1">
                  {['pending','paid','processing','shipped','completed','cancelled','failed'].map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function Admin() {
  const { user, loading: authLoading, isAdmin } = useAuth();
  const [tab, setTab] = useState('products');

  if (authLoading) return null;
  if (!user || !isAdmin) return <Navigate to="/" replace />;

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold font-display mb-8">Admin Dashboard</h1>

      <div className="flex gap-4 mb-8 border-b">
        {['products', 'orders'].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`pb-3 px-2 font-medium capitalize border-b-2 transition ${
              tab === t ? 'border-primary text-primary' : 'border-transparent text-gray-500'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === 'products' ? <AdminProducts /> : <AdminOrders />}
    </div>
  );
}
