import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../lib/api';
import ProductCard from '../components/ProductCard';

export default function Products() {
  const [searchParams, setSearchParams] = useSearchParams();
  const category = searchParams.get('category') || 'all';
  const q = searchParams.get('q') || '';
  const page = Number(searchParams.get('page') || 1);

  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchInput, setSearchInput] = useState(q);

  useEffect(() => {
    api.getCategories().then((data) => setCategories(data.categories)).catch(() => {});
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = { page, per_page: 12 };
    if (category !== 'all') params.category = category;
    if (q) params.q = q;

    api.getProducts(params)
      .then((data) => {
        setProducts(data.products);
        setPagination(data.pagination);
      })
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, [category, q, page]);

  function setFilter(nextCategory) {
    setSearchParams({ ...(q ? { q } : {}), category: nextCategory, page: '1' });
  }

  function handleSearchSubmit(e) {
    e.preventDefault();
    setSearchParams({ category, q: searchInput, page: '1' });
  }

  function goToPage(p) {
    setSearchParams({ ...(q ? { q } : {}), category, page: String(p) });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold font-display mb-3">All Products</h1>
        <p className="text-gray-600">Browse our full catalog of electronics and accessories</p>
      </div>

      <form onSubmit={handleSearchSubmit} className="max-w-md mx-auto mb-8 flex gap-2">
        <label htmlFor="product-search" className="sr-only">Search products</label>
        <input
          id="product-search"
          type="search"
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          placeholder="Search products..."
          className="flex-grow px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
        />
        <button type="submit" className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary-dark transition">
          <i className="fas fa-search" />
        </button>
      </form>

      <div className="flex justify-center mb-10">
        <div className="inline-flex flex-wrap justify-center rounded-md shadow-sm">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 text-sm font-medium rounded-l-lg ${category === 'all' ? 'bg-primary text-white' : 'bg-white hover:bg-gray-100'}`}
          >
            All
          </button>
          {categories.map((c, i) => (
            <button
              key={c.id}
              onClick={() => setFilter(c.slug)}
              className={`px-4 py-2 text-sm font-medium ${i === categories.length - 1 ? 'rounded-r-lg' : ''} ${
                category === c.slug ? 'bg-primary text-white' : 'bg-white hover:bg-gray-100'
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="bg-white rounded-lg h-80 animate-pulse" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <p className="text-center text-gray-500 py-12">
          No products match{q ? ` "${q}"` : ' this filter'}. Try a different search or category.
        </p>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {products.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>

          {pagination && pagination.total_pages > 1 && (
            <div className="flex justify-center gap-2">
              {Array.from({ length: pagination.total_pages }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => goToPage(i + 1)}
                  className={`w-9 h-9 rounded-md text-sm font-medium ${
                    pagination.page === i + 1 ? 'bg-primary text-white' : 'bg-white hover:bg-gray-100 border'
                  }`}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
