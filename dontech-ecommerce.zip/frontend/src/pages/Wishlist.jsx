import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../lib/api';
import { useCart } from '../context/CartContext';

export default function Wishlist() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const { addToCart } = useCart();

  useEffect(() => {
    api.getWishlist().then((data) => setItems(data.items)).finally(() => setLoading(false));
  }, []);

  async function handleRemove(productId) {
    await api.removeFromWishlist(productId);
    setItems((items) => items.filter((i) => i.product_id !== productId));
  }

  async function handleAddToCart(productId) {
    try {
      await addToCart(productId, 1);
    } catch (err) {
      alert(err.message);
    }
  }

  if (loading) {
    return <div className="container mx-auto px-4 py-20 text-center text-gray-500">Loading wishlist…</div>;
  }

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <i className="fas fa-heart text-5xl text-gray-300 mb-4" />
        <h1 className="text-2xl font-bold font-display mb-2">Your wishlist is empty</h1>
        <Link to="/products" className="bg-primary text-white px-6 py-3 rounded-md hover:bg-primary-dark transition">
          Browse Products
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold font-display mb-8">My Wishlist</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {items.map((item) => (
          <div key={item.wishlist_item_id} className="bg-white rounded-lg overflow-hidden shadow-md">
            <Link to={`/products/${item.slug}`}>
              <img src={item.image_url} alt={item.name} className="w-full h-48 object-cover" />
            </Link>
            <div className="p-4">
              <Link to={`/products/${item.slug}`} className="font-bold hover:text-primary block mb-2">{item.name}</Link>
              <p className="text-primary font-bold mb-3">${Number(item.price).toFixed(2)}</p>
              <div className="flex gap-2">
                <button
                  onClick={() => handleAddToCart(item.product_id)}
                  className="flex-1 bg-primary text-white py-2 rounded-md text-sm hover:bg-primary-dark transition"
                >
                  Add to Cart
                </button>
                <button
                  onClick={() => handleRemove(item.product_id)}
                  className="px-3 border rounded-md text-red-500 hover:bg-red-50 text-sm"
                  aria-label="Remove from wishlist"
                >
                  <i className="fas fa-trash" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
