export default function Contact() {
  return (
    <div className="container mx-auto px-4 py-16 max-w-2xl">
      <h1 className="text-3xl font-bold font-display mb-3 text-center">Get in Touch</h1>
      <p className="text-gray-600 text-center mb-10">
        Questions about an order, a repair, or a service? Reach us directly.
      </p>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
        <div className="bg-white rounded-lg shadow-sm p-6 text-center">
          <i className="fas fa-phone-alt text-primary text-2xl mb-3" />
          <p className="font-medium">+254 748 480 742</p>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-6 text-center">
          <i className="fas fa-envelope text-primary text-2xl mb-3" />
          <p className="font-medium break-all">odhiambodon@gmail.com</p>
        </div>
        <div className="bg-white rounded-lg shadow-sm p-6 text-center">
          <i className="fas fa-clock text-primary text-2xl mb-3" />
          <p className="font-medium">Mon–Fri, 9AM–6PM</p>
        </div>
      </div>

      <p className="text-center text-gray-500 text-sm">
        A contact form with backend handling can be added once you tell us where you'd like messages delivered (email, a ticketing tool, etc).
      </p>
    </div>
  );
}
