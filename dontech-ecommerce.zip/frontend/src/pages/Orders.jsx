import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../lib/api';

const statusColors = {
  pending: 'bg-yellow-100 text-yellow-700',
  paid: 'bg-blue-100 text-blue-700',
  processing: 'bg-blue-100 text-blue-700',
  shipped: 'bg-purple-100 text-purple-700',
  completed: 'bg-green-100 text-green-700',
  cancelled: 'bg-gray-100 text-gray-600',
  failed: 'bg-red-100 text-red-600',
};

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.getOrders().then((data) => setOrders(data.orders)).finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="container mx-auto px-4 py-20 text-center text-gray-500">Loading orders…</div>;
  }

  if (orders.length === 0) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <i className="fas fa-receipt text-5xl text-gray-300 mb-4" />
        <h1 className="text-2xl font-bold font-display mb-2">No orders yet</h1>
        <p className="text-gray-600 mb-6">Once you place an order, it'll show up here.</p>
        <Link to="/products" className="bg-primary text-white px-6 py-3 rounded-md hover:bg-primary-dark transition">
          Shop Products
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold font-display mb-8">My Orders</h1>
      <div className="space-y-4">
        {orders.map((o) => (
          <div key={o.id} className="bg-white rounded-lg shadow-sm p-5 flex flex-wrap justify-between items-center gap-3">
            <div>
              <p className="font-bold">{o.order_number}</p>
              <p className="text-sm text-gray-500">{new Date(o.created_at).toLocaleDateString()} · {o.payment_method === 'mpesa' ? 'M-Pesa' : 'Card'}</p>
            </div>
            <div className="flex items-center gap-4">
              <span className={`text-xs font-medium px-3 py-1 rounded-full ${statusColors[o.status] || 'bg-gray-100'}`}>
                {o.status}
              </span>
              <span className="font-bold">${Number(o.total).toFixed(2)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
